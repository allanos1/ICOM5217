//*****************************************************************************
//
// pressure_bmp180.c - Example to use of the SensorLib with the BMP180
//
// Copyright (c) 2013 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 1.0 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
//#include "inc/hw_ints.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
//#include "utils/uartstdio.h"
#include "sensorlib/hw_bmp180.h"
#include "sensorlib/i2cm_drv.h"
#include "sensorlib/bmp180.h"
//#include "drivers/rgb.h"

#include "a.lib/gpio.h"
#include "a.lib/lcd.h"
#include "a.lib/dht11.h"
#include "a.lib/loadCell.h"
#include "a.lib/bt.h"

/////
#define BMP180_I2C_ADDRESS  0x77
#define LCD_CMD_CURSOR_POSITION_LINE_3 0x94
#define LCD_CMD_CURSOR_POSITION_LINE_4 (0xA8 + LCD_CMD_POSITION_LINE_OFFSET+0x4)


uint32_t g_pui32Colors[3];
tI2CMInstance g_sI2CInst;
tBMP180 g_sBMP180Inst;
volatile uint_fast8_t g_vui8DataFlag;
float ABBMPTemperature;
float ABBMPPressure;


void BMP180AppCallback(void* pvCallbackData, uint_fast8_t ui8Status){
	if(ui8Status == I2CM_STATUS_SUCCESS) g_vui8DataFlag = 1;
}
void BMP180I2CIntHandler(void){
	I2CMIntHandler(&g_sI2CInst);
}

void ABBMPInit(){
	SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	GPIOPinConfigure(GPIO_PA6_I2C1SCL);
	GPIOPinConfigure(GPIO_PA7_I2C1SDA);
	GPIOPinTypeI2CSCL(GPIO_PORTA_BASE, GPIO_PIN_6);
	GPIOPinTypeI2C(GPIO_PORTA_BASE, GPIO_PIN_7);
	IntMasterEnable();
	I2CMInit(&g_sI2CInst, I2C1_BASE, INT_I2C1, 0xff, 0xff,
			SysCtlClockGet());
	BMP180Init(&g_sBMP180Inst, &g_sI2CInst, BMP180_I2C_ADDRESS,
			BMP180AppCallback, &g_sBMP180Inst);
	while(g_vui8DataFlag == 0);
	g_vui8DataFlag = 0;
}
void ABBMPUpdate(){
	BMP180DataRead(&g_sBMP180Inst, BMP180AppCallback, &g_sBMP180Inst);
	while(g_vui8DataFlag == 0);
	g_vui8DataFlag = 0;
	BMP180DataPressureGetFloat(&g_sBMP180Inst, &ABBMPPressure);
	BMP180DataTemperatureGetFloat(&g_sBMP180Inst, &ABBMPTemperature);

}
float ABBMPGetTemperature(){
	return ABBMPTemperature;
}

float ABBMPGetPressure(){
	return ABBMPPressure;
}

void ABLCDInit(){
	lcdInit(GPIO_PORTA,GPIO_PORTC,GPIO_PORTD);
	lcdClear();
	lcdCursorHome();
}


void ABDHT11Refresh(){
	dhtSetup();
	SysCtlDelay(10);
	dht11getData();
}

void ABDHT11Output(){
	lcdCursorHome();
	lcdWriteString("Hmd: .");
	lcdWriteNumber(dht11getHumidity());
	lcdWriteString(" T: .");
	lcdWriteNumberWithBounds(ABBMPTemperature,2,2);
	lcdWriteLetter(223);
	lcdWriteString("C.");
	lcdCursorHomeDown();
	lcdWriteString("Tmp: .");
	lcdWriteNumber(dht11getTemperature());
	lcdWriteString(" P: .");
	lcdWriteNumberWithBounds(ABBMPPressure/1000.0,3,2);
	lcdWriteString("kPa.");
}

void ABloadCellRefresh(){
	loadCellgetData();
}

void ABloadCellOutput(){
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
	lcdWriteString("S0:.");
	lcdWriteNumberWithBounds(loadCellgetValues(LOADCELL_LIFT_UP,OUNCES),2,2);
	lcdWriteString(" S1:.");
	lcdWriteNumberWithBounds(loadCellgetValues(LOADCELL_LIFT_DOWN,OUNCES),2,2);
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_4);
	lcdWriteString("S2:.");
	lcdWriteNumberWithBounds(loadCellgetValues(LOADCELL_DRAG_FRONT,OUNCES),2,2);
	lcdWriteString(" S3:.");
	lcdWriteNumberWithBounds(loadCellgetValues(LOADCELL_DRAG_BACK,OUNCES),2,2);
	lcdCursorHome();
}
void UARTIntHandler(void)
{
	uint32_t ui32Status;
	ui32Status = UARTIntStatus(UART0_BASE, true);
	UARTIntClear(UART0_BASE, ui32Status);
	while(UARTCharsAvail(UART0_BASE)){
		UARTCharPutNonBlocking(UART0_BASE,UARTCharGetNonBlocking(UART0_BASE));
	}
}

void ABUARTInit(){
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	//Port Activate
	GPIOPinConfigure(GPIO_PA0_U0RX);
	GPIOPinConfigure(GPIO_PA1_U0TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE,0x03);
	UARTConfigSetExpClk(UART0_BASE,SysCtlClockGet(),115200,0x60);
	IntEnable(INT_UART0);
	UARTIntEnable(UART0_BASE,0x50);

}

int
main(void)
{
	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_XTAL_16MHZ |SYSCTL_OSC_MAIN);
	ABLCDInit();
	ABBMPInit();
	loadCellSetup();
	ABUARTInit();
	BluetoothMainInit();



	while(1){
		ABDHT11Refresh();
		ABBMPUpdate();
		ABloadCellRefresh();
		lcdClear();
		ABDHT11Output();
		ABloadCellOutput();
		UARTSend("Something",9);
		SysCtlDelay(5000000);
	}
}

