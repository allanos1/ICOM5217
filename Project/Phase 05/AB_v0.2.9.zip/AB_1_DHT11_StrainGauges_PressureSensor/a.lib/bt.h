/*
 * bt.h
 *
 *  Created on: Nov 21, 2013
 *      Author: Administrator
 */

#ifndef BT_H_
#define BT_H_


void BluetoothMainInit();

#endif /* BT_H_ */
