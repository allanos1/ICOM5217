/*
 * ABMain.h
 *
 *  Created on: Nov 22, 2013
 *      Author: Administrator
 */

#ifndef ABMAIN_H_
#define ABMAIN_H_

//////////////////////////////////////////
// Includes 							//
//////////////////////////////////////////
#include "a.lib/gpio.h"
#include "a.lib/lcd.h"
#include "a.lib/dht11.h"
#include "a.lib/loadCell.h"
#include "a.lib/bt.h"
#include "a.lib/servo.h"


#define LCD_CMD_CURSOR_POSITION_LINE_3 0x94
#define LCD_CMD_CURSOR_POSITION_LINE_4 (0xA8 + LCD_CMD_POSITION_LINE_OFFSET+0x4)

//////////////////////////////////////////
// Pressure Sensor						//
//////////////////////////////////////////
//| - Defs
#define BMP180_I2C_ADDRESS  0x77

//| - Vars.
tI2CMInstance g_sI2CInst; // I2C Instance.
tBMP180 g_sBMP180Inst; //BMP180 Instance.
volatile uint_fast8_t g_vui8DataFlag;
float ABBMPTemperature;
float ABBMPPressure;

//| - Functions
void ABBMPInit();
void ABBMPUpdate();
float ABBMPGetTemperature();
float ABBMPGetPressure();

//////////////////////////////////////////
// Load Cells							//
//////////////////////////////////////////
float _ABLoadCellLiftUp;
float _ABLoadCellLiftDown;
float _ABLoadCellDragFront;
float _ABLoadCellDragBack ;
//////////////////////////////////////////

void ABLCDInit();
void ABDHT11Refresh();
void ABDHT11Output();
void ABLoadCellRefresh(int _ABLoadCellUnits);
void ABLoadCellOutput();
void UARTIntHandler(void);
void ABUARTInit();
void ABServoRefresh(int angle);

#endif /* ABMAIN_H_ */
