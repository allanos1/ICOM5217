/*
 * servo.c
 *
 *  Created on: Nov 20, 2013
 *      Author: JJLB
 */
/****************************************************/
/*					Instructions					*/
/****************************************************/
/*set a timer for timer() function
 *
 *
 *
 */
#include <stdint.h>
#include <stdbool.h>

#include "utils/uartstdio.h"

#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"
#include "driverlib/rom.h"
#include "inc/tm4c123gh6pm.h"
#include "servo.h"

void servoSetup();
void servosetPosition(int degrees);
int servogetPosition();
void servosetTimer();
void servoDisableTimer();
/****************************************************/
/*	Variable Definitions							*/
/****************************************************/
int up_time = 0;
int down_time = 40;
int currentPosition = 0;
int _servoState = 1;

/****************************************************/
/*				Function Definitions				*/
/****************************************************/

/****Main Functions****/

void servoSetup(){
	gpioSetMasterEnable(GPIO_PORTB);
	//SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
	gpioSetDirection(GPIO_PORTB,0x04,0x04);
	//GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE,GPIO_PIN_2);
	gpioSetDigitalEnable(GPIO_PORTB,0x04,0x04);
	gpioSetData(GPIO_PORTB,0x04,00);
	//GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_2, 0);
	servosetTimer();
}

void servosetTimer(){
	IntMasterEnable();
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER2);

	//SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

	TimerConfigure(TIMER2_BASE, TIMER_CFG_ONE_SHOT);

	TimerLoadSet(TIMER2_BASE, TIMER_A, SysCtlClockGet());

	IntEnable(INT_TIMER2A);

	TimerIntEnable(TIMER2_BASE, TIMER_TIMA_TIMEOUT);

	//TimerEnable(TIMER2_BASE, TIMER_A);

}
void servosetPosition(int degrees){
	currentPosition =(int)(4.2222*(degrees) + 440);
}
int servogetPosition(){
	return currentPosition;
}
void servoEnableTimer(){
	TimerEnable(TIMER2_BASE, TIMER_A);
}
void servoDisableTimer(){
	TimerDisable(TIMER2_BASE, TIMER_A);
}
/**** Helper Functions *****/

void servoTimer(){
	TimerIntClear(TIMER2_BASE, TIMER_TIMA_TIMEOUT);
	//some code here....
	GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, GPIOPinRead(GPIO_PORTB_BASE, GPIO_PIN_2) ^ GPIO_PIN_2);
	//gpioSetData(GPIO_PORTB | GPIO_OFFSET_DATA, 0x04,) ;

	if(_servoState){
		_servoState = 0;
		TimerLoadSet(TIMER2_BASE, TIMER_A, SysCtlClockGet()/currentPosition*10);
		TimerEnable(TIMER2_BASE, TIMER_A);
	}
	else{
		_servoState = 1 ;
		TimerLoadSet(TIMER2_BASE, TIMER_A, SysCtlClockGet()/down_time*10);
		TimerEnable(TIMER2_BASE, TIMER_A);
	}

}
