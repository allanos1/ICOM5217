/*
 * bt.h
 *
 *  Created on: Nov 21, 2013
 *      Author: Administrator
 */

#ifndef BT_H_
#define BT_H_

struct RollingBuffer;

void BluetoothMainInit();
void UARTBTSend(const uint8_t *pui8Buffer, uint32_t ui32Count);
void AddToBuffer(struct RollingBuffer *r, float value);
void InitBuffer(struct RollingBuffer *r);
void sendState(int state);
void sendMeasurements(float drag, float lift, float tilt);
void turnPowerOff();
void turnPowerOn();
void unlockPF0();
void sendDrag(float drag);
void sendLift(float lift);
void sendTilt(float tilt);
void sendDragMeasurement(float drag);
void sendLiftMeasurement(float lift);
void sendTiltMeasurement(float tilt);
void sendPressure(float pressure);
void sendHumidity(float humidity);
void sendSpeed(float speed);
void sendDirection(float direction);
void sendTemperature(float temperature);
void sendWindSpeed(float windSpeed);


#endif /* BT_H_ */
