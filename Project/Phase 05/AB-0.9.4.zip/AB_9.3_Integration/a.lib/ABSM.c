/*
 * ABSM.c
 *
 *  Created on: Nov 22, 2013
 *      Author: Administrator
 */

#include "ABSM.h"
#include "bt.h"
#include "driverlib/timer.h"

#define DESIRED_WIND_SPEED_RANGE 7.000
#define MEASURE_SIZE 20

char _measuring = 0;
char _measuringCount = 0;

float _ABLoadBase_NoWindDragFront;
float _ABLoadBase_NoWindDragBack;
float _ABLoadBase_NoWindLiftUp;
float _ABLoadBase_NoWindLiftDown;
float _ABLoadBase_WindDragFront;
float _ABLoadBase_WindDragBack;
float _ABLoadBase_WindLiftUp;
float _ABLoadBase_WindLiftDown;
float _ABLoadCombined_NoWindDragFront ;
float _ABLoadCombined_NoWindDragBack ;
float _ABLoadCombined_NoWindLiftUp ;
float _ABLoadCombined_NoWindLiftDown ;
float _ABLoadCombined_WindDragFront ;
float _ABLoadCombined_WindDragBack ;
float _ABLoadCombined_WindLiftUp ;
float _ABLoadCombined_WindLiftDown ;

float _wind_car_drag ;
float _wind_car_lift ;

float _wind_car_drag_values[MEASURE_SIZE] ;
float _wind_car_lift_values[MEASURE_SIZE] ;
float _average_pressure[MEASURE_SIZE];
float _average_temperature[MEASURE_SIZE];
float _average_humidity[MEASURE_SIZE];
float _average_direction[MEASURE_SIZE];

float _avg_pressure;
float _avg_temperature;
float _avg_humidity;
float _avg_direction;

char _anemometerServoSet = 0;


char anemometerServoSetIs(){
	return _anemometerServoSet;
}
void testTimer(){
	//lcdInit(GPIO_PORTA,GPIO_PORTC,GPIO_PORTD);
	//loadCellSetup();

	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ); //Setting the system clock
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER4); //Enabling the timer peripheral globally.
	TimerConfigure(TIMER4_BASE, TIMER_CFG_ONE_SHOT);  //Configuring for periodicity Or whatever.
	TimerLoadSet(TIMER4_BASE, TIMER_A, SysCtlClockGet()); //Setting the execution rate.
	IntEnable(INT_TIMER4A); //Enabling the interrupts for timers.
	TimerIntEnable(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER4_BASE, TIMER_A);
	//while(1);

}

float ABGetArrayAverage(float* array, int size){
	float average = 0 ;
	int i = 0;
	for(i = 0; i < size; i++){
		average += array[i];
	}
	average /= (float)size;
	return average ;
}
float ABGetAverageDrag(){

	return ABGetArrayAverage(_wind_car_drag_values,MEASURE_SIZE);
}
float ABGetAverageLift(){
	return ABGetArrayAverage(_wind_car_lift_values,MEASURE_SIZE);
}


void ABSMPrintScreen(char line1_en, char* line1,
					 char line2_en, char* line2,
					 char line3_en, char* line3,
					 char line4_en, char* line4){
	lcdClear();
	if(line1_en){
		lcdCursorHome();
		lcdWriteString(line1);
	}
	if(line2_en){
		lcdCursorHomeDown();
		lcdWriteString(line2);
	}
	if(line3_en){
		lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
		lcdWriteString(line3);
	}
	if(line4_en){
		lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_4);
		lcdWriteString(line4);
	}
}
//////////////////////////////////////////////////////////
// The Main State Sub Machine.
//////////
void ABSMMainPrintWelcomeMessage(){
	ABUIButtonsSetNextState(
			AB_STATE_MAIN_2_CALIBRATE,AB_STATE_MAIN_1_INIT,
			AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
			AB_STATE_MENU_MAIN,AB_STATE_MAIN_1_INIT);
	ABSMPrintScreen(1," Welcome To Aerobal  ",
					0,"",
					1,"Press Enter to Start",
					1,"   Calibration ");
	sendState(AB_STATE_MAIN_1_INIT);
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
	//Delays are outside the function.

}

void ABSMMain_2_EnterCalibrateSubMachine(){
	//Call Calibration State Machine.
	ABStateMachineState = AB_STATE_CALIBRATION_1_INIT;
	sendState(AB_STATE_MAIN_2_CALIBRATE);
}


void ABSMMain_4_ConfirmExperiment(){
	ABUIButtonsSetNextState(
			AB_STATE_MAIN_6_EXPERIMENT,AB_STATE_SM_NO_OPERATION,
				AB_STATE_MAIN_5_VERIFY_WIND_SPEED,AB_STATE_MAIN_1_INIT,
				AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	ABSMPrintScreen(1," Main_4 ",
						0,"",
						1,"Press Enter to Start",
						1,"   Experiment ");
	sendState(AB_STATE_MAIN_4_CONFIRM);
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

/*
 * Eliminated State.
 *

void ABSMMain_5_VerifyWindSpeed(){
	ABStateMachineState = AB_STATE_MAIN_6_EXPERIMENT;
	//
	ABSMPrintScreen(1," Main_5:  ",
					1," Setting Wind Speed",
					1," Don't Open Tunnel.",
					0,"");
	//turnPowerOn();
	//sendState(AB_STATE_MAIN_5_VERIFY_WIND_SPEED);
	//Verifying Wind Speed.
	//ABServoSet();
	ABStandardSysDelay(5000000);
}

*/

/**********************************************************************/
/**********************************************************************/
/**********************************************************************/

void ABSMMeasure(){

	//TODO: Clear Timer Interrupt.
	//Discrete values.

	TimerIntClear(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
	IntDisable(INT_TIMER4A);
	TimerDisable(TIMER4_BASE, TIMER_A);
	TimerIntDisable(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
	lcdClear();
	lcdWriteString("Recording: ");
	lcdWriteNumber(_measuringCount);


	SysCtlDelay(1000);
	ABLoadCellRefresh(OUNCES);
	_ABLoadCombined_WindDragFront = _ABLoadCellDragFront;
	_ABLoadCombined_WindDragBack = _ABLoadCellDragBack;
	_ABLoadCombined_WindLiftUp = _ABLoadCellLiftUp;
	_ABLoadCombined_WindLiftDown = _ABLoadCellLiftDown;

	float wind_base_drag_front = _ABLoadBase_WindDragFront - _ABLoadBase_NoWindDragFront;
	float wind_base_drag_back = _ABLoadBase_WindDragBack - _ABLoadBase_NoWindDragFront ;
	float wind_base_lift_up = _ABLoadBase_WindLiftUp - _ABLoadBase_NoWindLiftUp;
	float wind_base_lift_down = _ABLoadBase_WindLiftDown - _ABLoadBase_NoWindLiftDown ;

	float wind_comb_drag_front = _ABLoadCombined_WindDragFront - _ABLoadCombined_NoWindDragFront;
	float wind_comb_drag_back = _ABLoadCombined_WindDragBack - _ABLoadCombined_NoWindDragFront ;
	float wind_comb_lift_up = _ABLoadCombined_WindLiftUp - _ABLoadCombined_NoWindLiftUp;
	float wind_comb_lift_down = _ABLoadCombined_WindLiftDown - _ABLoadCombined_NoWindLiftDown ;

	//Wind on base and both.
	float wind_base_drag = (wind_base_drag_front > 0) ? wind_base_drag_front : wind_base_drag_back;
	float wind_base_lift = (wind_base_lift_up > 0) ? wind_base_lift_up : wind_base_lift_down;
	float wind_comb_drag = (wind_comb_drag_front > 0) ? wind_comb_drag_front : wind_comb_drag_back;
	float wind_comb_lift = (wind_comb_lift_up > 0) ? wind_comb_lift_up : wind_comb_lift_down;

	//Calculate wind car.
	_wind_car_drag = wind_comb_drag - wind_base_drag ;
	_wind_car_lift = wind_comb_lift - wind_base_lift ;




	SysCtlDelay(100000);
	//ABDHT11Refresh();
	SysCtlDelay(100000);
	ABBMPUpdate();



	lcdCursorHomeDown();
	lcdWriteString("D: ");
	lcdWriteNumberWithBounds(_wind_car_drag,2,2);
	lcdWriteString(" L: ");
	lcdWriteNumberWithBounds(_wind_car_lift,2,2);



	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
	lcdWriteString("P: ");
	lcdWriteNumberWithBounds(ABBMPPressure/1000.0,2,3);
	lcdWriteString(" T: ");
	lcdWriteNumberWithBounds(ABBMPTemperature,2,2);

	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_4);
	lcdWriteString("H: ");
	lcdWriteNumberWithBounds(dht11getHumidity(),2,2);

	lcdWriteString(" D: ");
	lcdWriteNumberWithBounds(_ABWindVaneAngle,2,2);

	_wind_car_drag_values[_measuringCount] = _wind_car_drag ;
	_wind_car_lift_values[_measuringCount] = _wind_car_lift ;
	_average_temperature[_measuringCount] = ABBMPTemperature ;
	_average_pressure[_measuringCount] = ABBMPPressure ;
	_average_humidity[_measuringCount] = dht11getHumidity();
	_average_direction[_measuringCount] = _ABWindVaneAngle;
	_measuringCount ++ ;

	UARTBTSend("BTSend\n",7);
	sendDragMeasurement(_wind_car_drag);
	sendLiftMeasurement(_wind_car_lift);
	sendTiltMeasurement(0.0);
	sendHumidity(dht11getHumidity());
	sendPressure(ABBMPPressure/1000.0);
	sendDirection(_ABWindVaneAngle);
	sendTemperature(ABBMPTemperature);
	sendWindSpeed(7.00);




	if(_measuringCount >= MEASURE_SIZE){
		IntDisable(INT_TIMER4A);
		TimerDisable(TIMER4_BASE, TIMER_A);
		TimerIntDisable(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
		ABUIButtonsSetNextState(
				AB_STATE_MAIN_7_CALCULATIONS,AB_STATE_MAIN_7_CALCULATIONS,
				AB_STATE_MAIN_7_CALCULATIONS,AB_STATE_MAIN_7_CALCULATIONS,
				AB_STATE_MAIN_7_CALCULATIONS,AB_STATE_MAIN_7_CALCULATIONS);
		ABStateMachineState = AB_STATE_MAIN_7_CALCULATIONS;
		_measuring = 0;
		ABStateMachineRun();
	}
	else{
		IntEnable(INT_TIMER4A); //Enabling the interrupts for timers.
		TimerIntEnable(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
		TimerEnable(TIMER4_BASE, TIMER_A);
	}





}

void ABSMMain_6_GetExperimentData(){
	ABUIButtonsSetNextState(
			AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION,
			AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION,
			AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	ABStateMachineState = AB_STATE_SM_NO_OPERATION;

	//
	ABSMPrintScreen(1," Main_6:  ",
						1," Recording Data:",
						0,"",
						0,"");
	//
	sendState(AB_STATE_MAIN_6_EXPERIMENT);
	turnPowerOn();

	////

	_measuringCount = 0;
	testTimer();

	//Take average of results.

	ABUIButtonEnable();
	////

}


/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
void ABSMMain_7_PerformCalculations(){
	ABStateMachineState = AB_STATE_MAIN_8_OUTPUT_RESULTS;

	//
	ABSMPrintScreen(1," Main_7:  ",
					1," Performing ",
					1," Calculations...",
					0,"");
	//
	sendState(AB_STATE_MAIN_7_CALCULATIONS);
	turnPowerOff();

	_wind_car_drag = ABGetAverageDrag();
	_wind_car_lift = ABGetAverageLift();
	_avg_temperature =ABGetArrayAverage(_average_temperature,MEASURE_SIZE);
	_avg_direction =ABGetArrayAverage(_average_direction,MEASURE_SIZE);
	_avg_pressure =ABGetArrayAverage(_average_pressure,MEASURE_SIZE);
	_avg_humidity =ABGetArrayAverage(_average_humidity,MEASURE_SIZE);

	ABStandardSysDelay(5000000);
}


void ABSMMain_8_OutputResults(){
	ABUIButtonsSetNextState(
			AB_STATE_MAIN_9_OUTPUT_RESULTS2,AB_STATE_MAIN_1_INIT,
					AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
					AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	//
	//
	sendState(AB_STATE_MAIN_8_OUTPUT_RESULTS);
	lcdClear();
	lcdWriteString("Result Averages:");
	lcdCursorHomeDown();
	lcdWriteString("Drag: ");
	lcdWriteNumberWithBounds(_wind_car_drag,2,2);
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
	lcdWriteString("Lift: ");
	lcdWriteNumberWithBounds(_wind_car_lift,2,2);
	//sendMeasurements(_wind_car_drag,_wind_car_lift,0);
	ABStandardSysDelay(5000000);

	ABUIButtonEnable();
}

void ABSMMain_9_OutputResults2(){
	ABUIButtonsSetNextState(
			AB_STATE_MAIN_10_OUTPUT_RESULTS3,AB_STATE_MAIN_1_INIT,
					AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
					AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	//
	//
	sendState(AB_STATE_MAIN_9_OUTPUT_RESULTS2);
	lcdClear();
	lcdWriteString("Sensor Averages:");
	lcdCursorHomeDown();
	lcdWriteString("P: ");
	lcdWriteNumberWithBounds(_avg_pressure/1000.0,2,3);
	lcdWriteString(" kPa");
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
	lcdWriteString("T: ");
	lcdWriteNumberWithBounds(_avg_temperature,2,2);
	lcdWriteString(" C");
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_4);
	lcdWriteString("Direction: ");
	lcdWriteNumberWithBounds(180.0 - _avg_direction,2,2);
	lcdWriteString(" N");
	if(180.0 - _avg_direction < 0){
		lcdWriteString("W");
	}
	else{
		lcdWriteString("E");
	}
	//sendMeasurements(_wind_car_drag,_wind_car_lift,0);
	ABStandardSysDelay(5000000);

	ABUIButtonEnable();
}

void ABSMMain_10_OutputResults3(){
	ABUIButtonsSetNextState(
			AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
					AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
					AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	//
	//
	sendState(AB_STATE_MAIN_10_OUTPUT_RESULTS3);
	lcdClear();
	lcdWriteString("Sensor Averages:");
	lcdCursorHomeDown();
	lcdWriteString("H: ");
	lcdWriteNumberWithBounds(_avg_humidity,2,2);
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
	lcdWriteString("Press Enter to");
	lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_4);
	lcdWriteString("Restart.");


	//sendMeasurements(_wind_car_drag,_wind_car_lift,0);
	ABStandardSysDelay(5000000);

	ABUIButtonEnable();
}
///////////////////////////////////////////////////////////
// The Calibrate State Sub Machine.
//////////
void ABSMCalibrate_1_Init(){
	ABUIButtonsSetNextState(
			AB_STATE_CALIBRATION_2_STORE_INIT_E,AB_STATE_SM_NO_OPERATION,
			AB_STATE_CALIBRATION_2_STORE_INIT_E,AB_STATE_MAIN_1_INIT,
			AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	//
	ABSMPrintScreen(1," Calibrate_1:  ",
					1," Make Sure Tunnel ",
					1," is Empty. Press",
					1," Enter to Calibrate");
	//
	sendState(AB_STATE_CALIBRATION_1_INIT);
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMCalibrate_2_StoreInitialValues_E(){
	ABStateMachineState = AB_STATE_CALIBRATION_3_CONFIG_CLOSED_TUNNEL;
	//
	ABSMPrintScreen(1," Calibrate_2:  ",
					1," Calibrating.... ",
					1," Please Wait.",
					0,"");
	//Read multiple values.

	sendState(AB_STATE_CALIBRATION_2_STORE_INIT_E);
	ABLoadCellRefresh(OUNCES);
	_ABLoadBase_NoWindDragFront = _ABLoadCellDragFront;
	_ABLoadBase_NoWindDragBack = _ABLoadCellDragBack;
	_ABLoadBase_NoWindLiftUp = _ABLoadCellLiftUp;
	_ABLoadBase_NoWindLiftDown = _ABLoadCellLiftDown;

	//BTSendData: those variables for initial config.

	ABStandardSysDelay(5000000);
	//ABUIButtonEnable();
}

void ABSMCalibrate_3_PromptForClosedTunnel(){
	ABUIButtonsSetNextState(
			AB_STATE_CALIBRATION_4_CHECK_WIND_SPEED,AB_STATE_SM_NO_OPERATION,
			AB_STATE_CALIBRATION_4_CHECK_WIND_SPEED,AB_STATE_MAIN_1_INIT,
			AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	//
	ABSMPrintScreen(1," Calibrate_3:  ",
					1," Close all tunnel",
					1," doors. Press enter",
					1," to continue.");
	//
	sendState(AB_STATE_CALIBRATION_3_CONFIG_CLOSED_TUNNEL);
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMCalibrate_4_CalibrateWindSpeed(){
	ABStateMachineState = AB_STATE_CALIBRATION_5_STORE_FINAL_E;
	//
	ABSMPrintScreen(1," Calibrate_4:  ",
					1," Calibrating wind",
					1," Don't Open Tunnel",
					0,"");
	//
	sendState(AB_STATE_CALIBRATION_4_CHECK_WIND_SPEED);
	turnPowerOn();

	//Turn on Wind Tunnel
	//ABServoSet();
	_anemometerServoSet = 1;
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();

}

void ABSMCalibrate_5_StoreFinalValues_E(){
	ABStateMachineState = AB_STATE_CALIBRATION_6_PROMPT_OBJECT;

	//
	ABSMPrintScreen(1," Calibrate_5:  ",
					1," Storing Final ",
					1," Values.",
					0,"");
	//
	sendState(AB_STATE_CALIBRATION_5_STORE_FINAL_E);
	ABLoadCellRefresh(OUNCES);
	_ABLoadBase_WindDragFront = _ABLoadCellDragFront;
	_ABLoadBase_WindDragBack = _ABLoadCellDragBack;
	_ABLoadBase_WindLiftUp = _ABLoadCellLiftUp;
	_ABLoadBase_WindLiftDown = _ABLoadCellLiftDown;
	ABStandardSysDelay(5000000);
	turnPowerOff();
	//ABUIButtonEnable();
}

void ABSMCalibrate_6_PromptForObject(){
	ABUIButtonsSetNextState(
			AB_STATE_CALIBRATION_7_STORE_INIT_O,AB_STATE_SM_NO_OPERATION,
				AB_STATE_CALIBRATION_7_STORE_INIT_O,AB_STATE_MAIN_1_INIT,
				AB_STATE_SM_NO_OPERATION,AB_STATE_SM_NO_OPERATION);
	//
	ABSMPrintScreen(1," Calibrate_6:  ",
					1," Place object",
					1," in tunnel base.",
					0,"");
	//
	sendState(AB_STATE_CALIBRATION_6_PROMPT_OBJECT);
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMCalibrate_7_StoreInitialValues_O(){
	ABStateMachineState = AB_STATE_MAIN_3_WIND_SETUP;
	//
	ABSMPrintScreen(1," Calibrate_7:  ",
					1," Storing initial",
					1," object values...",
					0,"");
	//
	sendState(AB_STATE_CALIBRATION_7_STORE_INIT_O);
	ABLoadCellRefresh(OUNCES);
	_ABLoadCombined_NoWindDragFront = _ABLoadCellDragFront;
	_ABLoadCombined_NoWindDragBack = _ABLoadCellDragBack;
	_ABLoadCombined_NoWindLiftUp = _ABLoadCellLiftUp;
	_ABLoadCombined_NoWindLiftDown = _ABLoadCellLiftDown;
	ABStandardSysDelay(5000000);
}

/////////////
void ABSMNoOperation(){
	ABUIButtonEnable();
}

//ABStateMachine_CAL : Calibration State Machine
