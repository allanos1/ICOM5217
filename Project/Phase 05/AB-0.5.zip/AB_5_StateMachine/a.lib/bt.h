/*
 * bt.h
 *
 *  Created on: Nov 21, 2013
 *      Author: Administrator
 */

#ifndef BT_H_
#define BT_H_


void BluetoothMainInit();
void UARTSend(const uint8_t *pui8Buffer, uint32_t ui32Count);
#endif /* BT_H_ */
