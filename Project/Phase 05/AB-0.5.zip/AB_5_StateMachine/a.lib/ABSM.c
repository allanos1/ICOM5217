/*
 * ABSM.c
 *
 *  Created on: Nov 22, 2013
 *      Author: Administrator
 */

#include "ABSM.h"

void ABSMPrintScreen(char line1_en, char* line1,
					 char line2_en, char* line2,
					 char line3_en, char* line3,
					 char line4_en, char* line4){
	lcdClear();
	if(line1_en){
		lcdCursorHome();
		lcdWriteString(line1);
	}
	if(line2_en){
		lcdCursorHomeDown();
		lcdWriteString(line2);
	}
	if(line3_en){
		lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_3);
		lcdWriteString(line3);
	}
	if(line4_en){
		lcdWriteCommand(LCD_CMD_CURSOR_POSITION_LINE_4);
		lcdWriteString(line4);
	}
}
//////////////////////////////////////////////////////////
// The Main State Sub Machine.
//////////
void ABSMMainPrintWelcomeMessage(){
	ABUIButtonsSetNextState(
			AB_STATE_MAIN_2_CALIBRATE,AB_STATE_VOID,
			AB_STATE_VOID,AB_STATE_MAIN_1_INIT,
			AB_STATE_VOID,AB_STATE_VOID);
	ABSMPrintScreen(1," Welcome To Aerobal  ",
					0,"",
					1,"Press Enter to Start",
					1,"   Calibration ");
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
	//Delays are outside the function.

}

void ABSMMain_2_EnterCalibrateSubMachine(){
	//Call Calibration State Machine.
	ABStateMachineState = AB_STATE_CALIBRATION_1_INIT;

}


void ABSMMain_4_ConfirmExperiment(){
	ABUIButtonsSetNextState(
				AB_STATE_MAIN_5_VERIFY_WIND_SPEED,AB_STATE_VOID,
				AB_STATE_VOID,AB_STATE_MAIN_1_INIT,
				AB_STATE_VOID,AB_STATE_VOID);
	ABSMPrintScreen(1," Main_4 ",
						0,"",
						1,"Press Enter to Start",
						1,"   Experiment ");
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMMain_5_VerifyWindSpeed(){
	ABStateMachineState = AB_STATE_MAIN_6_EXPERIMENT;
	//
	ABSMPrintScreen(1," Main_5:  ",
					1," Setting Wind Speed",
					1," Don't Open Tunnel",
					0,"");
	//
	ABStandardSysDelay(5000000);
}
void ABSMMain_6_GetExperimentData(){
	ABStateMachineState = AB_STATE_MAIN_7_CALCULATIONS;

	//
	ABSMPrintScreen(1," Main_6:  ",
						1," Recording Experiment",
						1," Data.",
						0,"");
	//
	ABStandardSysDelay(5000000);
}

void ABSMMain_7_PerformCalculations(){
	ABStateMachineState = AB_STATE_MAIN_8_OUTPUT_RESULTS;

	//
	ABSMPrintScreen(1," Main_7:  ",
					1," Performing ",
					1," Calculations...",
					0,"");
	//
	ABStandardSysDelay(5000000);
}

void ABSMMain_8_OutputResults(){
	ABUIButtonsSetNextState(
					AB_STATE_MAIN_1_INIT,AB_STATE_VOID,
					AB_STATE_VOID,AB_STATE_MAIN_1_INIT,
					AB_STATE_VOID,AB_STATE_VOID);
	//
	ABSMPrintScreen(1," Main_8:  ",
					1," Here are the ",
					1," results: smthing",
					0," smthing dark side.");
	//
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}


///////////////////////////////////////////////////////////..........
// The Calibrate State Sub Machine.
//////////
void ABSMCalibrate_1_Init(){
	ABUIButtonsSetNextState(
			AB_STATE_CALIBRATION_2_STORE_INIT_E,AB_STATE_MAIN_1_INIT,
			AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
			AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT);
	//
	ABSMPrintScreen(1," Calibrate_1:  ",
					1," Make Sure Tunnel ",
					1," is Empty. Press",
					1," Enter to Calibrate");
	//
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMCalibrate_2_StoreInitialValues_E(){
	ABStateMachineState = AB_STATE_CALIBRATION_3_CONFIG_CLOSED_TUNNEL;
	//
	ABSMPrintScreen(1," Calibrate_2:  ",
					1," Calibrating.... ",
					1," Please Wait.",
					0,"");
	//
	ABStandardSysDelay(5000000);
	//ABUIButtonEnable();
}

void ABSMCalibrate_3_PromptForClosedTunnel(){
	ABUIButtonsSetNextState(
			AB_STATE_CALIBRATION_4_CHECK_WIND_SPEED,AB_STATE_MAIN_1_INIT,
			AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
			AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT);
	//
	ABSMPrintScreen(1," Calibrate_3:  ",
					1," Please Close all  ",
					1," Tunnel Doors.",
					0,"");
	//
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMCalibrate_4_CalibrateWindSpeed(){
	ABStateMachineState = AB_STATE_CALIBRATION_5_STORE_FINAL_E;
	//
	ABSMPrintScreen(1," Calibrate_4:  ",
					1," Calibrating Wind",
					1," Don't Open Tunnel",
					0,"");
	//
	ABStandardSysDelay(5000000);
}

void ABSMCalibrate_5_StoreFinalValues_E(){
	ABStateMachineState = AB_STATE_CALIBRATION_6_PROMPT_OBJECT;

	//
	ABSMPrintScreen(1," Calibrate_5:  ",
					1," Storing Final ",
					1," Values.",
					0,"");
	//

	ABStandardSysDelay(5000000);
	//ABUIButtonEnable();
}

void ABSMCalibrate_6_PromptForObject(){
	ABUIButtonsSetNextState(
				AB_STATE_CALIBRATION_7_STORE_INIT_O,AB_STATE_MAIN_1_INIT,
				AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT,
				AB_STATE_MAIN_1_INIT,AB_STATE_MAIN_1_INIT);
	//
	ABSMPrintScreen(1," Calibrate_6:  ",
					1," Place object",
					1," in tunnel base.",
					0,"");
	//
	ABStandardSysDelay(5000000);
	ABUIButtonEnable();
}

void ABSMCalibrate_7_StoreInitialValues_O(){
	ABStateMachineState = AB_STATE_MAIN_3_WIND_SETUP;
	//
	ABSMPrintScreen(1," Calibrate_7:  ",
					1," Storing initial",
					1," object values..",
					0,"");
	//
	ABStandardSysDelay(5000000);
}



//ABStateMachine_CAL : Calibration State Machine
