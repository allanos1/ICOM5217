/************************************************/
// System Includes - ARM
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
//#include "inc/tm4c123gh6pm.h"
//#include "inc/hw_nvic.h"
//#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
//#include "driverlib/debug.h"
//#include "driverlib/fpu.h"
//#include "driverlib/gpio.h"
//#include "driverlib/systick.h"
//#include "driverlib/uart.h"
//#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"
/***********************************************/
// Libraries
#include "a.lib/gpio.h"
#include "a.lib/dht11.h"
#include "a.lib/lcd.h"
/***********************************************/


int main(void){

	lcdInit(GPIO_PORTA,GPIO_PORTC,GPIO_PORTD);


	while(1){
		dhtSetup();
		dht11getData();

		SysCtlDelay(10000000);

		lcdClear();
		lcdCursorHome();
		lcdWriteString("RelativeHumidity:.");
		lcdCursorHomeDown();
		lcdWriteString("  .");
		lcdWriteNumber(dht11getHumidity());
		lcdWriteString("% at .");
		//lcdCursorHomeDown();
		//lcdWriteString("Temp: .");
		lcdWriteNumber(dht11getTemperature());
		lcdWriteData(0xDF);
		lcdWriteString("C.");
		//while(1);
	}
}


