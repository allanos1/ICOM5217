/*
 * ABUI.h
 *
 *  Created on: Nov 22, 2013
 *      Author: Administrator
 *      #TODO organize, organize, organize!
 */

#ifndef ABUI_H_
#define ABUI_H_

#include "ABMain.h"
#include "ABSM.h"
#include "lcd.h"
#include "gpio.h"

#define AB_UI_BUTTON_STANDARD_DELAY 200000

//////
// Button Definitions
#define _ABUIButtonB0_UP 0x01
#define _ABUIButtonB1_DOWN 0x02
#define _ABUIButtonB2_ENTER 0x04
#define _ABUIButtonB3_CANCEL 0x08
#define _ABUIButtonB4_MENU 0x10
#define _ABUIButtonB5_OPTION 0x20

#define ABUI_ENABLED_BUTTONS 0x3F

//////////////////////////
//Button States



//////////////////////////
//Functions

///////////////////////
//Buttons Interrupt.
void ABUIButtonInterrupt();
void ABUIButtonsSetNextState(char _ABUIBB0NextState,char _ABUIBB1NextState,
		char _ABUIBB2NextState, char _ABUIBB3NextState,
		char _ABUIBB4NextState, char _ABUIBB5NextState);
void ABUIButtonSetNextState(char _ABUIButton, char _ABSMNextState);
void ABUIPrintStateInvalid(char state);
void ABUIButtonSetup();

//Implementation Definition.
extern void ABStateMachineChangeState(int state);
extern void ABStateMachineRun();
void ABUIButtonDisable();
void ABUIButtonEnable();
#endif /* ABUI_H_ */
