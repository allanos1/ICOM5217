#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "gpio.h"
#include "lcd.h"

#define TIMER_FREQUENCY 1024

int milliseconds;
int seconds;
int write;
int stopped;

int fourth = -1 ;
int third = -1 ;
int second = -1;

int direction ;
int count = 0;
int rpm = 0;


//Change to port and pin selection.
void IntFinish(){
	HWREG(0x4002441C) = 0x06 ;
}

//Change to port and pin selection.
void IntMaskEnable(){
	HWREG(0x40024410) = 0x06;
}


//Init the interrupt framework.
void initInterruptModule(){
	IntMasterEnable();
	IntEnable(INT_GPIOE);
	HWREG(0x40024408)= 0x00;
	HWREG(0x4002440C) = 0x00;
	IntMaskEnable();
}

void initTimerModule(){
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
	TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/1000);//
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER0_BASE, TIMER_A);
}



void tacometerWriteDirection(){
	lcdCursorHomeDown();
	lcdWriteString("      .");
	if(direction == -1) lcdWriteLetter('<');
	else lcdWriteLetter(' ');
	lcdWriteString("  .");
	//CW
	if(direction == 1) lcdWriteLetter('>');
	else lcdWriteLetter(' ');

}

void tacometerWriteRPM(){
	lcdCursorHome();
	lcdWriteString("RPM: .");

	int t_rpm = rpm;
	//Fourth Digit.
	if(t_rpm >=1000){
		fourth = t_rpm/1000;
		lcdWriteLetter(fourth+48);
		fourth*=1000;
		t_rpm-=fourth;
	}
	else{
		lcdWriteLetter(0+48);
	}
	//Third Digit.
	if(t_rpm >= 100){
		third = t_rpm/100;
		lcdWriteLetter(third+48);
		third*=100;
		t_rpm-=third;
	}
	else{
		lcdWriteLetter(0+48);
	}
	//Second Digit.
	if(t_rpm >= 10){
		second=t_rpm/10;
		lcdWriteLetter(second+48);
		second*=10;
		t_rpm-=second;
	}
	else{
		lcdWriteLetter(0+48);
	}

	//First Digit.
	lcdWriteLetter(t_rpm+48);

}

void timerCount(){
	TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	milliseconds++ ;
	if(milliseconds >= 1000){
		seconds++;
		milliseconds = 0;
		if(stopped == 1){
			rpm = 0 ;
		}

	}
	if(milliseconds == 500){
		stopped = 1 ;
	}

}

void movedABlock(){
	SysCtlDelay(20000);
	int ris = HWREG(0x40024414) & 0x06;
	int data = HWREG(0x400243FC) & 0x06;
	if(data == 0x06 || ris == 0x06){
		count++;
		if(count >= 7){
			int ms = (seconds*1000 + milliseconds);
			rpm = (((float)60)*((float)1))/((float)ms/(float)1000);
			count = 0;
			seconds = 0;
			milliseconds = 0;
			stopped = 0;
		}
	}
	else if(ris == 0x04){
		direction = 1 ;
	}
	else if(ris == 0x02){
		direction = -1;
	}

	IntFinish();
}

int main(void){

	volatile uint32_t ui32Loop;

	// Enable the GPIO ports that are used for the on-board LED.
	portActivate(GPIO_PORTA);
	portActivate(GPIO_PORTC);
	portActivate(GPIO_PORTE);
	portActivate(GPIO_PORTD);

	//Set Direction for each register port.
	portDirection(GPIO_PORTA, 0x0C);
	portDirection(GPIO_PORTC, 0xF0);
	portDirection(GPIO_PORTD, 0x0F);
	portDirection(GPIO_PORTE, 0x00);

	//Digital Enable.
	portDigitalEnable(GPIO_PORTA,0x0C);
	portDigitalEnable(GPIO_PORTC,0xF0);
	portDigitalEnable(GPIO_PORTD,0x0F);
	portDigitalEnable(GPIO_PORTE,0xFF);

	//Write Commands to Initialize LCD.
	lcdInit(GPIO_PORTA|GPIO_OFFSET_DATA,
			GPIO_PORTC|GPIO_OFFSET_DATA,
			GPIO_PORTD|GPIO_OFFSET_DATA);

	milliseconds = 0;
	seconds = 0;
	write = 1;
	direction = 0 ;

	lcdWriteLines("Timer Testing.",".");
	SysCtlDelay(20000000);
	lcdClear();
	initInterruptModule();
	initTimerModule();

	while(1){
		if(write){
			///////////////////////
			//RPM
			tacometerWriteRPM();

			///////////////////////
			//Direction
			tacometerWriteDirection();

		}
	}

}


