/*
 * helloLCD.h
 *
 *  Created on: Sep 29, 2013
 *      Author: Administrator
 */

#ifndef HELLOLCD_H_
#define HELLOLCD_H_

#include <stdint.h>
#include "inc/hw_types.h"
#include "inc/tm4c123gh6pm.h"

#define	GPIO_PORTA 0x40004000
#define GPIO_PORTB 0x40005000
#define GPIO_PORTC 0x40006000
#define GPIO_PORTD 0x40007000
#define GPIO_PORTE 0x40024000
#define GPIO_PORTF 0x40025000
#define GPIO_OFFSET_DATA 0x000003FC
#define GPIO_OFFSET_DIRECTION 0x00000400
#define GPIO_OFFSET_INTERRUPT_SENSE 0x00000404
#define GPIO_OFFSET_INTERRUPT_BOTH_EDGES 0x00000408

void portActivate(uint32_t port);
void portDirection(uint32_t port, uint32_t direction);
void portDigitalEnable(uint32_t port, uint32_t enable);



#endif /* HELLOLCD_H_ */
