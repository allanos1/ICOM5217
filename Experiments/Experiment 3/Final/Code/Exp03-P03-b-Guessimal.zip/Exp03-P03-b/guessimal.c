

#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "gpio.h"
#include "lcd.h"

#define TIMER_FREQUENCY 1024

int tries = 0 ;
int selection = 0 ;
int target = 0 ;


//Change to port and pin selection.
void IntFinish(){
	HWREG(0x4002441C) = 0x06 ;
}

//Change to port and pin selection.
void IntMaskEnable(){
	HWREG(0x40024410) = 0x06;
}


//Init the interrupt framework.
void initInterruptModule(){
	IntMasterEnable();
	IntEnable(INT_GPIOE);
	HWREG(0x40024408)= 0x00;
	HWREG(0x4002440C) = 0x00;
	IntMaskEnable();
}

void initTimerModule(){
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
	TimerLoadSet(TIMER0_BASE, TIMER_A, ROM_SysCtlClockGet()/(TIMER_FREQUENCY*2));
	TimerEnable(TIMER0_BASE, TIMER_A);
}

void gameBlinkingMessage(char* message1, char* message2, int times){
	int i = 0 ;
	while(i < times){
		lcdClear();
		lcdWriteLines(message1,message2);
		SysCtlDelay(10000000);
		lcdClear();
		SysCtlDelay(2000000);
		i++;
	}
}


void gameWriteSelection(int selection){
	lcdCursorHomeDown();
	lcdWriteString("     < .");
	lcdWriteLetter(selection);
	lcdWriteString(" >      .");
}

int gamePressedRight(){
	return HWREG(0x40024414) & 0x02 ;
}

int gamePressedLeft(){
	return HWREG(0x40024414) & 0x04 ;
}

int gamePressedBoth(){
	return HWREG(0x40024414) & 0x06 ;
}
int gameValidate(){
	if(target == selection){
		return 1 ;
	}
	else{
		return 0;
	}
}


void gameInit(){
	lcdClear();
	lcdCursorHome() ;
	gameBlinkingMessage("  Welcome to .","   Guessimal  .", 2);
	lcdWriteLines("Select Number:.","     < 0 >.");
}
void gameReset(){
	tries = 3 ;
	selection = 0;
	target = TimerValueGet(TIMER0_BASE,TIMER_A) % 10;
	gameInit();
}

void gameLose(){
	lcdWriteLineUp(" You lose :( .");
	lcdClearLine(LCD_LINE_DOWN);
	lcdCursorHomeDown();
	lcdWriteString("Number: .");
	lcdWriteLetter(target+48);
}
void gameSelectionRight(){
	selection=(selection+1)%10 ;
	gameWriteSelection(selection+48);
}

void gameSelectionLeft(){
	selection=(selection-1);
	if(selection<0) selection= 9 ;
	gameWriteSelection(selection+48) ;
}
void gameTryAgain(){
	selection = 0 ;
	lcdWriteLines("Select Number:.","     < 0 >.");
}

int gameCheckDecision(){
	if(gameValidate()){
		lcdWriteLineUp(" You win! :D.");
		SysCtlDelay(20000000);
		return 1 ;
	}
	else{
		//UI Stuff.
		lcdClearLine(LCD_LINE_DOWN);

		//Tries left.
		if(tries > 0){
			tries--;
			lcdWriteLineUp(" Try again :/.");
			SysCtlDelay(4000000);
			return 0;
		}
		//No tries left.
		else{
			gameLose();
			SysCtlDelay(20000000);
			return 1;
		}
	}

}

void switchPressed(){
	//Wait for other button.
	SysCtlDelay(2000000);
	if(gamePressedBoth() == 0x06){
		if(gameCheckDecision()){
			gameReset();
		}
		else{
			gameTryAgain();
		}
	}
	else if(gamePressedRight()){
		gameSelectionRight();
	}
	else{
		gameSelectionLeft();
	}
	SysCtlDelay(2000000);
	IntFinish();
}

int main(void){

	volatile uint32_t ui32Loop;

	// Enable the GPIO ports that are used for the on-board LED.
	portActivate(GPIO_PORTA);
	portActivate(GPIO_PORTC);
	portActivate(GPIO_PORTE);
	portActivate(GPIO_PORTD);

	//Set Direction for each register port.
	portDirection(GPIO_PORTA, 0x0C);
	portDirection(GPIO_PORTC, 0xF0);
	portDirection(GPIO_PORTD, 0x0F);
	portDirection(GPIO_PORTE, 0x00);

	//Digital Enable.
	portDigitalEnable(GPIO_PORTA,0x0C);
	portDigitalEnable(GPIO_PORTC,0xF0);
	portDigitalEnable(GPIO_PORTD,0x0F);
	portDigitalEnable(GPIO_PORTE,0xFF);

	//Write Commands to Initialize LCD.
	lcdInit(GPIO_PORTA|GPIO_OFFSET_DATA,
			GPIO_PORTC|GPIO_OFFSET_DATA,
			GPIO_PORTD|GPIO_OFFSET_DATA);

	initInterruptModule();
	initTimerModule();

	gameReset();

	while(1);

}


