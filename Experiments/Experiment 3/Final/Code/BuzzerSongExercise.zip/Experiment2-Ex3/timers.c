//*****************************************************************************
//
// timers.c - Timers example.
//
// Copyright (c) 2012-2013 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 1.0 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "gpio.h"
#include "notes.h"

//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>Timer (timers)</h1>
//!
//! This example application demonstrates the use of the timers to generate
//! periodic interrupts.  One timer is set up to interrupt once per second and
//! the other to interrupt twice per second; each interrupt handler will toggle
//! its own indicator on the display.
//!
//! UART0, connected to the Virtual Serial Port and running at 115,200, 8-N-1,
//! is used to display messages from this application.
//
//*****************************************************************************


//*****************************************************************************
//
// Flags that contain the current value of the interrupt indicator as displayed
// on the UART.
//
//*****************************************************************************
uint32_t g_ui32Flags;

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

int freq = 1000;
int note = 0;
int note2 = 0;
int note_count = 35;
int notesOctave[];
float song[1000];
char eliseSong[2000] = "E D# E D# E B D C A C E A B E G# B C E E D# E D# E B D C A C E A B E C B A A B C D E G F E D F E D C E D C B C E A E E D# E D# E B D C A A E A C E A E B E G# E C B A A E A B C D C E G C G F E G D G B F E D A C E A E D C E B E E E E E E E E D# E D# E D# E D# E D# E D# E B D C A A E A C E A E B E G# E G# B A C E A E E D# E D# E B D C A A E A C E A E B E G# E C B A A E A Bb C E C A C F C G C E Bb C F C A F A C A C F A E F E Bb D D Bb D Bb Bb A F A E G F G Bb F E E F G Bb D E C F Bb A C A A C A Bb G A A Bb F C A C A C D A D# E E A C A E D D F F A G C F G F G D G B C E C G G G A G F G B G E G C G D F G D G C E G E G C B F A A G F E G B D G F D C C G G G A G F G B G E G C G D F G D G C E G E G C B F A A G F E G B D G F D G# B E F E D# E B E D# E B E D# E B E D# E B E D# E D# E D# E D# E D# E B D C A A E A C E A E B E G# E G# B A C E A E E D# E D# E B D C A A E A C E A E B E G# E C B A A E A B C D C E G C G F E G D G B F E D A C E A E D C E B E E E E E E E E D# E D# E D# E D# E D# E D# E B D C A A E A C E A E B E G# E G# B A C E A E E D# E D# E B D C A A E A C E A E B E G# E C B A A A A A A A A E G Bb C# A A A A A A F A D A A A A C# E A D F A G# D F A A A A G# D F A A A C E A A A A A D A F D D A D A D A D A E C D A D B D A C F # A D A D A D A D A C A D A E A C A E A E A E C E A E G# D B E G # A A C A A A A A A A E G Bb C# A A A A A A F A D A A A A C# E A D F A D F A A A A D F A Bb D F Bb Bb Bb Bb Bb Bb G Eb Bb Bb Bb Bb FD Bb Eb C Bb D F Bb Bb Bb Bb Bb D F A Bb B D F Ab B B B B D F Ab B C C E A E G# E B A A C E A C E A C E D C B A C E A C E A C E A C E D C B A C E A C E A C E A C E D C B A C E Bb A G# G F# F E D# D C# C B Bb A G# G F# F E D# E B D C A A E A C E A E B E G# E G# B A C E A E E D# E D# E B D C A A E A C E A E B E G# E C B A A E A B C D C E G C G F E G D G B F E D A C E A E D C E B E E E E E E E E D# E D# E D# E D# E D# E D# E B D C A A E A C E A E B E G# E G# B A C E A E E D# E D# E B D C A A E A C E A E B E G# E C B A A A ";
char sillySong[100] = "E D C D E E E D D D E E E E D C D E E E D D E D C ";
int counteri = 0;
int pushed = 0;

void inc(){

	int ris = HWREG(0x40007414) ;
	int one_hertz =  ROM_SysCtlClockGet()/2;
	int notesOctave2[8]={16.35,18.35,20.60,21.83,24.52,27.50,30.87,32.70};


	if(ris & 0x00000001){

		pushed = 1;

	}
	else{
		ROM_TimerLoadSet(TIMER0_BASE, TIMER_A,  one_hertz/(notesOctave2[note2]*32));
		note2 = (note2 + 1) % 8;
	}

	SysCtlDelay(2000000);
	IntFinish();

}

void convertStringToNotes(){
	int x = 0;
	int add = 0;
	while(add < 888){
		switch(eliseSong[add]){
		case 'C': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_c;
							  add += 2;
							  break;
					case '#': song[x] = notes_c_sharp;
							  add += 3;
							  break;
				}
		break;
		case 'D': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_d;
							  add += 2;
							  break;
					case '#': song[x] = notes_d_sharp;
							  add += 3;
							  break;
					case 'b': song[x] = notes_d_flat;
							  add += 3;
							  break;
				}
		break;
		case 'E': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_e;
							  add += 2;
							  break;
					case 'b': song[x] = notes_e_flat;
							  add += 3;
							  break;
				}
		break;
		case 'F': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_f;
							  add += 2;
							  break;
					case '#': song[x] = notes_f_sharp;
							  add += 3;
							  break;
				}
		break;
		case 'G': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_g;
							  add += 2;
							  break;
					case '#': song[x] = notes_g_sharp;
							  add += 3;
							  break;
					case 'b': song[x] = notes_g_flat;
							  add += 3;
							  break;
				}
		break;
		case 'A': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_a;
							  add += 2;
							  break;
					case '#': song[x] = notes_a_sharp;
							  add += 3;
							  break;
					case 'b': song[x] = notes_a_flat;
							  add += 3;
							  break;
				}
		break;
		case 'B': switch(eliseSong[ add + 1]){
					case ' ': song[x] = notes_b;
							  add += 2;
							  break;
					case 'b': song[x] = notes_b_flat;
							  add += 3;
							  break;
				}
		break;
		}
		x++;
	}
}

void nextTone(){
	int one_hertz =  ROM_SysCtlClockGet()/2;
	ROM_TimerLoadSet(TIMER0_BASE, TIMER_A,  one_hertz/(song[counteri]*32));
	//SysCtlDelay(1000000);
}

void nextToneWithTime(int time){
	int one_hertz =  ROM_SysCtlClockGet()/2;
	ROM_TimerLoadSet(TIMER0_BASE, TIMER_A,  one_hertz/(song[counteri]*32));
	SysCtlDelay(time);
}
//*****************************************************************************
//
// The interrupt handler for the first timer interrupt.
//
//*****************************************************************************
void
Timer0IntHandler(void)
{
    //
    // Clear the timer interrupt.
    //
    ROM_TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    //
    // Toggle the flag for the first timer.
    //
    HWREGBITW(&g_ui32Flags, 0) ^= 1;

    //
    // Use the flags to Toggle the LED for this timer
    //
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, g_ui32Flags << 1);

}

//*****************************************************************************
//
// The interrupt handler for the second timer interrupt.
//
//*****************************************************************************
void
Timer1IntHandler(void)
{
    //
    // Clear the timer interrupt.
    //
    ROM_TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);

    //
    // Toggle the flag for the second timer.
    //
    HWREGBITW(&g_ui32Flags, 1) ^= 1;

    //
    // Use the flags to Toggle the LED for this timer
    //
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, g_ui32Flags << 1);

}

//Change to port and pin selection.
void IntFinish(){
	HWREG(0x4000741C) = 0x03 ;
}

//Change to port and pin selection.
void IntMaskEnable(){
	HWREG(0x40007410) = 0x03; //Activating Port B
	//_asm("MOV R1, R2");
}


//*****************************************************************************
//

// This example application demonstrates the use of the timers to generate
// periodic interrupts.
//
//*****************************************************************************
int main(void)
{
    // Enable lazy stacking for interrupt handlers.  This allows floating-point
    // instructions to be used within interrupt handlers, but at the expense of
    // extra stack usage.
    ROM_FPULazyStackingEnable();

    //
    // Set the clocking to run directly from the crystal.
    //
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    // Initialize the UART and write status.
    //
    //ConfigureUART();

    //UARTprintf("\033[2JTimers example\n");
    //UARTprintf("T1: 0  T2: 0");

    //
    // Enable the GPIO port that is used for the on-board LED.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);

    //
    // Enable the GPIO pins for the LED (PF1 & PF2).
    //
    ROM_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_2 | GPIO_PIN_1);
    ROM_GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_1 | GPIO_PIN_0 );

    IntEnable(INT_GPIOD);
    IntMaskEnable();

    // Enable the peripherals used by this example.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);

    //
    // Enable processor interrupts.
    //
    ROM_IntMasterEnable();

    //
    // Configure the two 32-bit periodic timers.
    //
    ROM_TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    ROM_TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
    ROM_TimerLoadSet(TIMER0_BASE, TIMER_A, ROM_SysCtlClockGet()/2);
    ROM_TimerLoadSet(TIMER1_BASE, TIMER_A, ROM_SysCtlClockGet());

    //
    // Setup the interrupts for the timer timeouts.
    //
    ROM_IntEnable(INT_TIMER0A);
    ROM_IntEnable(INT_TIMER1A);
    ROM_TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    ROM_TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);

    //
    // Enable the timers.
    //
    ROM_TimerEnable(TIMER0_BASE, TIMER_A);
    ROM_TimerEnable(TIMER1_BASE, TIMER_A);

    //Music
    allNoteScaler(0);

    convertStringToNotes();

    //
    // Loop forever while the timers run.
    //
    while(1){
    	if(pushed == 1){
    	for(counteri = 0;counteri < 1000;counteri++){
    	nextTone();
    	SysCtlDelay(2500000);

    	}

    	}
pushed = 0;
    	ROM_TimerLoadSet(TIMER0_BASE, TIMER_A, ROM_SysCtlClockGet()/2);
    }
}
