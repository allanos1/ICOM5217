/*
 * gpio.c
 *
 *  Created on: Sep 30, 2013
 *      Author: Administrator
 */
#include "gpio.h"

void portActivate(uint32_t port){
	switch(port){
		case GPIO_PORTA: SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA; break ;
		case GPIO_PORTB: SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOB; break ;
		case GPIO_PORTC: SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOC; break ;
		case GPIO_PORTD: SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOD; break ;
		case GPIO_PORTE: SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOE; break ;
		case GPIO_PORTF: SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF; break ;
	}
	//Dummy Read.
	uint32_t ui32Loop = SYSCTL_RCGC2_R;
	return ;
}

void portDirection(uint32_t port, uint32_t direction){
	//offset = 0x400
	switch(port){
		case GPIO_PORTA: HWREG(GPIO_PORTA | GPIO_OFFSET_DIRECTION) = direction; break ;
		case GPIO_PORTB: HWREG(GPIO_PORTB | GPIO_OFFSET_DIRECTION) = direction; break ;
		case GPIO_PORTC: HWREG(GPIO_PORTC | GPIO_OFFSET_DIRECTION) = direction; break ;
		case GPIO_PORTD: HWREG(GPIO_PORTD | GPIO_OFFSET_DIRECTION) = direction; break ;
		case GPIO_PORTE: HWREG(GPIO_PORTE | GPIO_OFFSET_DIRECTION) = direction; break ;
		case GPIO_PORTF: HWREG(GPIO_PORTF | GPIO_OFFSET_DIRECTION) = direction; break ;
	}
}

void portDigitalEnable(uint32_t port, uint32_t enable){
	switch(port){
		case GPIO_PORTA: GPIO_PORTA_DEN_R = enable; break ;
		case GPIO_PORTB: GPIO_PORTB_DEN_R = enable; break ;
		case GPIO_PORTC: GPIO_PORTC_DEN_R = enable; break ;
		case GPIO_PORTD: GPIO_PORTD_DEN_R = enable; break ;
		case GPIO_PORTE: GPIO_PORTE_DEN_R = enable; break ;
		case GPIO_PORTF: GPIO_PORTF_DEN_R = enable; break ;
	}
}



