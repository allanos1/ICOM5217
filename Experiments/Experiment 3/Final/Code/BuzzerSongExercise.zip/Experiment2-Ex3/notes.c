/*
 * notes.c
 *
 *  Created on: Oct 6, 2013
 *      Author: JJLB
 */
#include "notes.h";

void allNoteScaler(float octave){

	float scaler = octave + 1;

	notes_c = NOTES_C0 * scaler;
	notes_c_sharp = NOTES_C0_SHARP * scaler;
	notes_d_flat = NOTES_D0_FLAT * scaler;
	notes_d = NOTES_D0 * scaler;
	notes_d_sharp = NOTES_D0_SHARP * scaler;
	notes_e_flat = NOTES_E0_FLAT * scaler;
	notes_e = NOTES_E0 * scaler;
	notes_f = NOTES_F0 * scaler;
	notes_f_sharp = NOTES_F0_SHARP * scaler;
	notes_g_flat = NOTES_G0_FLAT * scaler;
	notes_g = NOTES_G0 * scaler;
	notes_g_sharp = NOTES_G0_SHARP * scaler;
	notes_a_flat = NOTES_A0_FLAT * scaler;
	notes_a = NOTES_A0 * scaler;
	notes_a_sharp = NOTES_A0_SHARP * scaler;
	notes_b_flat = NOTES_B0_FLAT * scaler;
	notes_b = NOTES_B0 * scaler;

}

float noteScaler(float note, float octave){

	float scaler = octave + 1;
	return note * scaler;

}



