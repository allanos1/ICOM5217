/*
 * notes.h
 *
 *  Created on: Oct 6, 2013
 *      Author: JJLB
 */

#ifndef NOTES_H_
#define NOTES_H_

#define NOTES_C0	16.35
#define NOTES_C0_SHARP 17.32
#define NOTES_D0_FLAT 17.32
#define NOTES_D0	18.35
#define NOTES_D0_SHARP 19.45
#define NOTES_E0_FLAT 19.45
#define NOTES_E0	20.60
#define NOTES_F0	21.83
#define NOTES_F0_SHARP 23.12
#define NOTES_G0_FLAT 23.12
#define NOTES_G0	24.50
#define NOTES_G0_SHARP 25.96
#define NOTES_A0_FLAT 25.96
#define NOTES_A0	27.50
#define NOTES_A0_SHARP 29.14
#define NOTES_B0_FLAT 29.14
#define NOTES_B0	30.87

int notes_c;
int notes_c_sharp;
int notes_d_flat;
int notes_d;
int notes_d_sharp;
int notes_e_flat;
int notes_e;
int notes_f;
int notes_f_sharp;
int notes_g_flat;
int notes_g;
int notes_g_sharp;
int notes_a_flat;
int notes_a;
int notes_a_sharp;
int notes_b_flat;
int notes_b;

void allNoteScaler(float octave);
float noteScaler(float note, float octave);



#endif /* NOTES_H_ */
