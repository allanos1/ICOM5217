

#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "gpio.h"
#include "lcd.h"

const int MESSAGE_SET_SIZE = 17;
char* c[] = { "Experiment 2    .", "LCD Interface   .", "with Tiva MCU  .",
		"Use the wheel   .", "to scroll up and.", "down through the.", "menu, thanks! :D.",
		"Hello World!    .", "Hello Anthony!  .", "Hello Juan!     .",
		"AeroBal Micro 2 .", "Hakuna Matata   .", "If this doesn't .",
		"work, it was    .", "Anthony's fault .", ",if it works,    .", "Juan did it! :) ." };


void nextString(int i);
void menuUp(int i);
void menuDown(int i);
void IntFinish();
void IntMaskEnable();
void interruptInit();
void switchPressed();

int cursor = 0;
int direction = 0;

void writeString(char* string){
	int i;
	for(i = 0; string[i] != '.' ;i++){
		 lcdWriteData(string[i]);
	}
}

void nextString(int i){
	lcdCursorHome();
	writeString(c[(i%MESSAGE_SET_SIZE)]);
	SysCtlDelay(200000);
	lcdCursorHomeDown();
	writeString(c[(i+1)%MESSAGE_SET_SIZE]);
	SysCtlDelay(200000);

}

//Stub for modularization. Interrupt calls. Up.
void menuUp(int i){
	cursor-- ;
	cursor = (cursor < 0) ? MESSAGE_SET_SIZE-1 : cursor;
	nextString(i);
}

//Stub for modularization. Interrupt calls. Down.
void menuDown(int i){
	cursor = (cursor+1)%MESSAGE_SET_SIZE;
	nextString(i);
}

void writeLetter(char letter){
	lcdWriteData(letter);
}

//Change to port and pin selection.
void IntFinish(){
	HWREG(0x4002441C) = 0x06 ;
}

//Change to port and pin selection.
void IntMaskEnable(){
	HWREG(0x40024410) = 0x06; //Activating Port B
	//_asm("MOV R1, R2");
}


//Init the interrupt framework.
void initInterruptModule(){
	 IntMasterEnable();
	 IntEnable(INT_GPIOE);
	 IntMaskEnable();
	 HWREG(0x40024408)= 0xFF;
}
#define GPIO_OFFSET_RAW_INT_STATUS 0x00000414
#define BIT_1 0x02
#define BIT_2 0x04
/*
void switchPressed(){

	uint32_t raw_interrupt_status = HWREG(GPIO_PORTE | GPIO_OFFSET_RAW_INT_STATUS);
	uint32_t data = HWREG(0x400243FC) & 0x06;

	if((data & BIT_2) && (data & BIT_1)){
		if(direction < 0 && (raw_interrupt_status & 0x04)){
			menuUp(cursor);
		}
		else if(direction > 0 && (raw_interrupt_status & 0x02)){
			menuDown(cursor);
		}
		direction = 0; //Reset.
		SysCtlDelay(300000);
	}
	//Moving right.
	else if(raw_interrupt_status & BIT_2){
		direction = 1 ;
	}
	//Moving Left.
	else if(raw_interrupt_status & BIT_1){
		direction = -1 ;
	}

	IntFinish();
	return;

}
*/

void switchPressed(){

	uint32_t ris = HWREG(0x40024414);
	uint32_t data = HWREG(0x400243FC);
	data = data & 0x06;

	if((data & 0x04) && (data & 0x02)){
		if(direction < 0 && (ris & 0x04)){
			//Move up in circular array.
					cursor-- ;
					cursor = (cursor < 0) ? MESSAGE_SET_SIZE-1 : cursor;
					menuUp(cursor);
					//Delay and set software debouncing variable.
					SysCtlDelay(300000);
		}
		else if(direction > 0 && (ris & 0x02)){
			cursor = (cursor+1)%MESSAGE_SET_SIZE;
					menuDown(cursor);
					//Delay and set software debouncing variable.
					SysCtlDelay(300000);
		}
		else{
			//Do nothing.
		}
		//Reset.
		direction = 0;
	}
	//MOving right.
	else if(ris & 0x04){
		direction = 1 ;

	}
	//Moving Left.
	else if(ris & 0x02){
		direction = -1 ;
	}

	//SysCtlDelay(2000000);
	IntFinish();
	//while(1);
	return;

}

int main(void){
	volatile uint32_t ui32Loop;

	// Enable the GPIO ports that are used for the on-board LED.
	portActivate(GPIO_PORTA);
	portActivate(GPIO_PORTC);
	portActivate(GPIO_PORTE);
	portActivate(GPIO_PORTD);

	//Set Direction for each register port.
	portDirection(GPIO_PORTA, 0x0C);
	portDirection(GPIO_PORTC, 0xF0);
	portDirection(GPIO_PORTD, 0x0F);
	portDirection(GPIO_PORTE, 0x00);

	//Digital Enable.
	portDigitalEnable(GPIO_PORTA,0x0C);
	portDigitalEnable(GPIO_PORTC,0xF0);
	portDigitalEnable(GPIO_PORTD,0x0F);
	portDigitalEnable(GPIO_PORTE,0xFF);

	//Write Commands to Initialize LCD.
	lcdInit(GPIO_PORTA|GPIO_OFFSET_DATA,
			GPIO_PORTC|GPIO_OFFSET_DATA,
			GPIO_PORTD|GPIO_OFFSET_DATA);

	cursor = 0 ;
	nextString(cursor);

	initInterruptModule();
	//init();
	while(1);

}


