/*
 * lcd.c
 *
 *  Created on: Sep 30, 2013
 *      Author: Anthony
 */

#include "lcd.h"

//////////////////////////////////////////
// API Layer 0

void lcdWriteToPort(uint32_t hex){

	//Using Upper: PINs: 7, 6, 5, 4
	HWREG(_lcdPortDataUpper) = (hex & 0xF0) ;

	//Using Lower: PINs: 3, 2, 1, 0
	HWREG(_lcdPortDataLower) = (hex & 0x0F) ;

}

void lcdWriteCommit(){
	//Set Enable (E) line to high
	//to begin data accept.
	HWREG(_lcdPortControl) |= 0x08;

	//Wait for LCD to accept data.
	SysCtlDelay(20000);

	//Set Enable (E) to low to finish
	//data accept.
	HWREG(_lcdPortControl) &= 0xF7 ;

}

void lcdWriteCommand(uint32_t hexCommand){


	//PIN2 = RS (Register Select)
	//PIN3 = E  (Enable)
	//SET RS to low
	//SET E to low
	HWREG(_lcdPortControl) &= 0xF3;

	//Write the command to port.
	lcdWriteToPort(hexCommand);

	//Commit the command.
	lcdWriteCommit();

}

void lcdWriteData(uint32_t hexData){

	//PIN2 = RS (Register Select)
	//PIN3 = E  (Enable)
	//SET RS to High
	//SET E to low
	HWREG(_lcdPortControl) |= 0x04;
	HWREG(_lcdPortControl) &= 0xF7;

	//Write the data to port.
	lcdWriteToPort(hexData);

	//Commit the data.
	lcdWriteCommit();


}
//////////////////////////////////////////
// API Layer 1

void lcdClear(){
	lcdWriteCommand(LCD_CMD_CLEAR);
}

void lcdCursorUp(){
	//Requires Read.
}
void lcdCursorDown(){
	//Requires Read.
}
void lcdCursorHide(){
	lcdWriteCommand(LCD_CMD_CURSOR_HIDE);
}
void lcdCursorHome(){
	lcdWriteCommand(LCD_CMD_POSITION_UP);
}
void lcdCursorHomeDown(){
	lcdWriteCommand(LCD_CMD_POSITION_DOWN);
}
void lcdCursorMoveLeft(){
	lcdWriteCommand(LCD_CMD_CURSOR_MOVE_LEFT);
}
void lcdCursorMoveRight(){
	lcdWriteCommand(LCD_CMD_CURSOR_MOVE_RIGHT);
}
void lcdDisplayHide(){
	lcdWriteCommand(LCD_CMD_DISPLAY_BLANK);
}
void lcdDisplayRestore(){
	lcdWriteCommand(LCD_CMD_DISPLAY_RESTORE);
}
void lcdScrollLeft(){
	lcdWriteCommand(LCD_CMD_SCROLL_LEFT);
}
void lcdScrollRight(){
	lcdWriteCommand(LCD_CMD_SCROLL_RIGHT);
}


//////////////////////////////////////////
// API Layer 2
void lcdInit(uint32_t __lcdPortControl,
				uint32_t __lcdPortDataUpper,
				uint32_t __lcdPortDataLower){
	_lcdPortControl = __lcdPortControl;
	_lcdPortDataUpper = __lcdPortDataUpper;
	_lcdPortDataLower = __lcdPortDataLower;
	lcdWriteCommand(LCD_CMD_FSET_2L_8B);
	lcdWriteCommand(LCD_CMD_FSET_ENTRY_INCREMENT_NOSHIFT);
	lcdWriteCommand(LCD_CMD_CURSOR_UNDERLINE_STATIC);
	lcdClear();
	_lcdInited = 1 ;
}
