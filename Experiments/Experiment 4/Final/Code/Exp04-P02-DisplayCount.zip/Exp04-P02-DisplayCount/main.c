/************************************************/
// System Includes - ARM
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
//#include "inc/tm4c123gh6pm.h"
//#include "inc/hw_nvic.h"
//#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
//#include "driverlib/debug.h"
//#include "driverlib/fpu.h"
//#include "driverlib/gpio.h"
//#include "driverlib/systick.h"
//#include "driverlib/uart.h"
//#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"
/***********************************************/
// Libraries
#include "a.lib/gpio.h"
#include "a.lib/lcd.h"
/***********************************************/

int counter1 = 0;
int counter2 = 0;
int state = 0;
uint32_t values[] = { ~0xD7, ~0x84, ~0xE3, ~0xE6,
					  ~0xB4, ~0x76, ~0x77, ~0xC4,
					  ~0xF7, ~0xF4, ~0xF5, ~0xFF,
					  ~0x53, ~0xDF, ~0x73, ~0x71 };


void timer0A(){
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	if(++counter1 > 15){
		counter1 = 0;
		counter2++;
	}
	if(counter2 > 15){
		counter2 = 0;
		counter1 = 0;
	}
}

void timer1A(){
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    if(state) {
    	gpioSetData(GPIO_PORTA,0x08);
    	gpioSetData(GPIO_PORTD, values[counter1]&0x0F);
    	gpioSetData(GPIO_PORTC, values[counter1]&0xF0);

    }
    else {
    	gpioSetData(GPIO_PORTA,0x04);
    	gpioSetData(GPIO_PORTD, values[counter2]&0x0F);
    	gpioSetData(GPIO_PORTC, values[counter2]&0xF0);
    }
    state = !state;
}
void initTimerModule(){
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
	TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
	TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet());
	TimerLoadSet(TIMER1_BASE, TIMER_A, SysCtlClockGet()/120);
	IntEnable(INT_TIMER0A);
	IntEnable(INT_TIMER1A);
	TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER0_BASE, TIMER_A);
	TimerEnable(TIMER1_BASE, TIMER_A);
}

int main(void){
	gpioSetMasterEnable(GPIO_PORTA);
	gpioSetMasterEnable(GPIO_PORTC);
	gpioSetMasterEnable(GPIO_PORTD);

	gpioSetDirection(GPIO_PORTA,0x0C);
	gpioSetDirection(GPIO_PORTC,0xF0);
	gpioSetDirection(GPIO_PORTD,0x0F);

	gpioSetDigitalEnable(GPIO_PORTA,0x0C);
	gpioSetDigitalEnable(GPIO_PORTC,0xF0);
	gpioSetDigitalEnable(GPIO_PORTD,0x0F);


	gpioSetData(GPIO_PORTA,0x0C);


	initTimerModule();

	while(1);
}


