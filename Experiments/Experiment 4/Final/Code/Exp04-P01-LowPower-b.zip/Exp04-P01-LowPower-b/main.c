/************************************************/
// System Includes - ARM
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
//#include "inc/tm4c123gh6pm.h"
//#include "inc/hw_nvic.h"
//#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
//#include "driverlib/debug.h"
//#include "driverlib/fpu.h"
//#include "driverlib/gpio.h"
//#include "driverlib/systick.h"
//#include "driverlib/uart.h"
//#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"
#include "driverlib/cpu.h"
/***********************************************/
// Libraries
#include "a.lib/gpio.h"
#include "a.lib/lcd.h"
/***********************************************/


void toggle(){
	SysCtlDelay(8000000);
	gpioSetData(GPIO_PORTD, gpioGetData(GPIO_PORTD)^0x01);
	gpioSetInterruptClear(GPIO_PORTB,0xFF);

}
/*
int main(void){

	gpioSetMasterEnable(GPIO_PORTB);
	gpioSetDirection(GPIO_PORTB,0x00);
	gpioSetDigitalEnable(GPIO_PORTB, 0xFF);

	gpioSetMasterEnable(GPIO_PORTD);
	gpioSetDirection(GPIO_PORTD,0x01);
	gpioSetDigitalEnable(GPIO_PORTD,0xFF);

	HWREG(NVIC_SYS_CTRL_R)|=NVIC_SYS_CTRL_SLEEPEXIT;

	gpioHelperInterruptMasterEnable();
	gpioSetInterruptEnable(GPIO_PORTB);
	gpioSetInterruptBothEdges(GPIO_PORTB,0x00);
	gpioSetInterruptEvent(GPIO_PORTB, 0xFF);
	gpioSetInterruptMaskDisable(GPIO_PORTB,0xFF);

	CPUwfi();


}

*/
