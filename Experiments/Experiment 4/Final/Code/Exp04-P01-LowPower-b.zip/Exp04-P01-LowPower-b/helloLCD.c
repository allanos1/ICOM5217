

#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "driverlib/cpu.h"
#include "utils/uartstdio.h"
#include "a.lib/gpio.h"
#include "a.lib/lcd.h"

const int MESSAGE_SET_SIZE = 17;
char* c[] = { "Experiment 2    .", "LCD Interface   .", "with Tiva MCU  .",
		"Use the wheel   .", "to scroll up and.", "down through the.", "menu, thanks! :D.",
		"Hello World!    .", "Hello Anthony!  .", "Hello Juan!     .",
		"Hi, Mom! :D     .", "I love you! :3  .", "If this doesn't .",
		"work, it was    .", "Anthony's fault .", ",if it works,    .", "Juan did it! :) ." };


void nextString(int i);
void menuUp(int i);
void menuDown(int i);
void IntFinish();
void IntMaskEnable();
void interruptInit();
void switchPressed();

int cursor = 0;
int direction = 0;


void nextString(int i){
	lcdCursorHome();
	lcdWriteString(c[(i%MESSAGE_SET_SIZE)]);
	SysCtlDelay(200000);
	lcdCursorHomeDown();
	lcdWriteString(c[(i+1)%MESSAGE_SET_SIZE]);
	SysCtlDelay(200000);

}

//Stub for modularization. Interrupt calls. Up.
void menuUp(int i){
	cursor-- ;
	cursor = (cursor < 0) ? MESSAGE_SET_SIZE-1 : cursor;
	nextString(cursor);
}

//Stub for modularization. Interrupt calls. Down.
void menuDown(int i){
	cursor = (cursor+1)%MESSAGE_SET_SIZE;
	nextString(cursor);
}

//Change to port and pin selection.
void IntFinish(){
	HWREG(0x4002441C) = 0x06 ;
}

//Change to port and pin selection.
void IntMaskEnable(){
	HWREG(0x40024410) = 0x06; //Activating Port B
	//_asm("MOV R1, R2");
}


//Init the interrupt framework.
void initInterruptModule(){

	 gpioSetInterruptBothEdges(GPIO_PORTE,0x00);
	 gpioSetInterruptEvent(GPIO_PORTE,0x00);
	 IntMasterEnable();
	 IntEnable(INT_GPIOE);
	 IntMaskEnable();
}
#define GPIO_OFFSET_RAW_INT_STATUS 0x00000414
#define BIT_1 0x02
#define BIT_2 0x04

void switchPressed(){

	SysCtlDelay(300000);
	uint32_t ris = HWREG(0x40024414);

	if(ris & 0x02){
		menuDown(cursor);
		//Delay and set software debouncing variable.

	}
	//Moving Left.
	else if(ris & 0x04){
		//Move up in circular array.
		menuUp(cursor);
		//Delay and set software debouncing variable.

	}

	SysCtlDelay(300000);
	IntFinish();

}

int main(void){
	volatile uint32_t ui32Loop;

	// Enable the GPIO ports that are used for the on-board LED.
	gpioSetMasterEnable(GPIO_PORTA);
	gpioSetMasterEnable(GPIO_PORTC);
	gpioSetMasterEnable(GPIO_PORTE);
	gpioSetMasterEnable(GPIO_PORTD);

	//Set Direction for each register port.
	gpioSetDirection(GPIO_PORTA, 0x0C);
	gpioSetDirection(GPIO_PORTC, 0xF0);
	gpioSetDirection(GPIO_PORTD, 0x0F);
	gpioSetDirection(GPIO_PORTE, 0x00);

	//Digital Enable.
	gpioSetDigitalEnable(GPIO_PORTA,0x0C);
	gpioSetDigitalEnable(GPIO_PORTC,0xF0);
	gpioSetDigitalEnable(GPIO_PORTD,0x0F);
	gpioSetDigitalEnable(GPIO_PORTE,0xFF);

	//Write Commands to Initialize LCD.
	lcdInit(GPIO_PORTA|GPIO_OFFSET_DATA,
			GPIO_PORTC|GPIO_OFFSET_DATA,
			GPIO_PORTD|GPIO_OFFSET_DATA);

	cursor = 0 ;
	nextString(cursor);

	initInterruptModule();
	//init();
	while(1){
		CPUwfi();
	}

}


