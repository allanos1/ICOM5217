/************************************************/
// System Includes - ARM
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
//#include "inc/tm4c123gh6pm.h"
//#include "inc/hw_nvic.h"
//#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
//#include "driverlib/debug.h"
//#include "driverlib/fpu.h"
//#include "driverlib/gpio.h"
//#include "driverlib/systick.h"
//#include "driverlib/uart.h"
//#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"
/***********************************************/
// Libraries
#include "a.lib/gpio.h"
#include "a.lib/lcd.h"
/***********************************************/

int lsb = 0;
int msb = 0;
int state = 0;
uint32_t values[] = { ~0xD7, ~0x84, ~0xE3, ~0xE6,
					  ~0xB4, ~0x76, ~0x77, ~0xC4,
					  ~0xF7, ~0xF4, ~0xF5, ~0xFF,
					  ~0x53, ~0xDF, ~0x73, ~0x71 };


uint32_t keypadReadPortPins(uint32_t port, uint32_t pins){
	return gpioGetData(port) & pins;
}

int keypadReadRow(uint32_t rport, uint32_t rpin, int d1, int d2, int d3){
	 gpioSetData(rport,rpin);
	 if(keypadReadPortPins(GPIO_PORTA,0xE0)){

		 if(keypadReadPortPins(GPIO_PORTA, 0x80)){
			msb=lsb;
	    	lsb=d1 ;
	    	gpioSetData(rport,0x00);
	    	return 1;
		 }
		 else if(keypadReadPortPins(GPIO_PORTA,0x40)){
			 msb=lsb;
			 lsb=d2;
			 gpioSetData(rport,0x00);
			 return 1 ;
		 }
		 else if(keypadReadPortPins(GPIO_PORTA,0x20)){
			 msb=lsb;
			 lsb=d3;
			 gpioSetData(rport,0x00);
			 return 1;
		 }

	 }
 	 gpioSetData(rport,0x00);
	 return 0;
}

void timer0A(){
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    //PB1 PE4 PE5 PB4 PA5 PA6 PA7
    //SysCtlDelay(200000);

    if(!keypadReadRow(GPIO_PORTB, 0x02,3,2,1))
    if(!keypadReadRow(GPIO_PORTE, 0x10,6,5,4))
    if(!keypadReadRow(GPIO_PORTE, 0x20,9,8,7))
    keypadReadRow(GPIO_PORTB, 0x10,11,0,10);
    TimerEnable(TIMER0_BASE,TIMER_A);
}

void timer1A(){
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    if(state) {
    	gpioSetData(GPIO_PORTA,0x08);
    	gpioSetData(GPIO_PORTD, values[lsb]&0x0F);
    	gpioSetData(GPIO_PORTC, values[lsb]&0xF0);

    }
    else {
    	gpioSetData(GPIO_PORTA,0x04);
    	gpioSetData(GPIO_PORTD, values[msb]&0x0F);
    	gpioSetData(GPIO_PORTC, values[msb]&0xF0);
    }
    state = !state;
}
void initTimerModule(){
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
	TimerConfigure(TIMER0_BASE, TIMER_CFG_ONE_SHOT);
	TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
	TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/10);
	TimerLoadSet(TIMER1_BASE, TIMER_A, SysCtlClockGet()/120);
	IntEnable(INT_TIMER0A);
	IntEnable(INT_TIMER1A);
	TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER0_BASE, TIMER_A);
	TimerEnable(TIMER1_BASE, TIMER_A);
}

int main(void){

	gpioSetMasterEnable(GPIO_PORTA);
	gpioSetMasterEnable(GPIO_PORTB);
	gpioSetMasterEnable(GPIO_PORTC);
	gpioSetMasterEnable(GPIO_PORTD);
	gpioSetMasterEnable(GPIO_PORTE);

	//PB1 PE4 PE5 PB4 PA5 PA6 PA7
	//x02 x10 x20 x10 x20 x40 x80
	gpioSetDirection(GPIO_PORTA,0x0C);
	gpioSetDirection(GPIO_PORTB,0x12);
	gpioSetDirection(GPIO_PORTC,0xF0);
	gpioSetDirection(GPIO_PORTD,0x0F);
	gpioSetDirection(GPIO_PORTE,0x30);

	gpioSetDigitalEnable(GPIO_PORTA,0xEC);
	gpioSetDigitalEnable(GPIO_PORTB,0x12);
	gpioSetDigitalEnable(GPIO_PORTC,0xF0);
	gpioSetDigitalEnable(GPIO_PORTD,0x0F);
	gpioSetDigitalEnable(GPIO_PORTE,0x30);


	gpioSetData(GPIO_PORTA,0x0C);
	initTimerModule();
	while(1);
}


