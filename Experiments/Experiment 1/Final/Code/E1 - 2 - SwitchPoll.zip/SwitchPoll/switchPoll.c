#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include <stdint.h>
#include "inc/tm4c123gh6pm.h"

int main(void){

    volatile uint32_t ui32Loop;
    int ledStatus = 0;
    //
    // Enable the GPIO port that is used for the on-board LED.
    //
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF;
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOD;

    // From Tiva Tutorial.
    // Do a dummy read to insert a few cycles after enabling the peripheral.
    //
    ui32Loop = SYSCTL_RCGC2_R;

    //
    // Enable the GPIO pins for the LED (PF1,PF2,PF3,PD1).  Set the direction as output, and
    // enable the GPIO pin for digital function(PD0).
    //
    GPIO_PORTF_DIR_R = 0x0E;
    GPIO_PORTF_DEN_R = 0x0E;

    GPIO_PORTD_DIR_R = 0x02;
    GPIO_PORTD_DEN_R = 0x03;

    //
    // Loop forever.
    //
    int wasPressed = 0;
    while(1){

    	//Turn on LED when off.
    	if(((GPIO_PORTD_DATA_R & 0x01) == 0x01) && !ledStatus && !wasPressed){	//Check PD0 Status
    		GPIO_PORTF_DATA_R = 0x0E;			//Turn On onboard leds
    		GPIO_PORTD_DATA_R |= 0x02;			//Turn On external led
    		ledStatus = 1;
    		wasPressed = 1;
    		SysCtlDelay(9000000);

    	}
    	//Turn off LED when on.
    	else if(((GPIO_PORTD_DATA_R & 0x01) == 0x01) && ledStatus && !wasPressed) {
    		GPIO_PORTF_DATA_R = 0x00;			//Turn OFF onboard leds
    		GPIO_PORTD_DATA_R &= 0xFD;			//Turn OFF external led
    		ledStatus = 0;
    		wasPressed = 1;
    		SysCtlDelay(9000000);
    	}
    	//To help eliminate debouncing.
    	else if(!(GPIO_PORTD_DATA_R & 0x01)){
    		wasPressed = 0 ;
    	}

    }
}

